import React, { useRef, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { captureRef } from 'react-native-view-shot';
import * as Sharing from 'expo-sharing';
import { LAST_WEEK, formatLength, formatWeight, infoForWeek } from '../pregnancy';
import { Habitat } from '../components/Habitat';
import { BabyFigure } from '../components/BabyFigure';
import { photoUri } from '../photos';
import { Relation, wordsFor } from '../relations';
import { C, ui } from '../theme';

type Extra = 'fact' | 'vs';

/** Instagram/Snapchat story-sized images of a week's beast: one beast vs baby, one gross fact. */
export function ShareCard({
  week,
  photoFile,
  relation,
  nickname = '',
  onClose,
}: {
  week: number | null;
  photoFile?: string;
  relation: Relation;
  nickname?: string;
  onClose: () => void;
}) {
  const vsRef = useRef<View>(null);
  const factRef = useRef<View>(null);
  const { width: winW, height: winH } = useWindowDimensions();
  const [withPhoto, setWithPhoto] = useState(true);
  const [secret, setSecret] = useState(false);
  const [busy, setBusy] = useState<'both' | 'one' | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState(0); // which image of two is being shared
  const [page, setPage] = useState(0);

  const visible = week !== null;
  // Secret mode only makes the gross fact image: vs Baby gives the game away
  const modes: Extra[] = secret ? ['fact'] : ['vs', 'fact'];
  const current = modes[Math.min(page, modes.length - 1)];

  // Fit a 9:16 card on screen with room for the controls below it
  const cardW = Math.min(winW - 48, (winH * 0.5 * 9) / 16);
  const cardH = (cardW * 16) / 9;

  const capture = (ref: React.RefObject<View | null>) =>
    captureRef(ref, { format: 'png', quality: 1, result: 'tmpfile', width: 1080, height: 1920 });

  const shareOne = async () => {
    setError(null);
    setBusy('one');
    try {
      const uri = await capture(current === 'vs' ? vsRef : factRef);
      if (!(await Sharing.isAvailableAsync())) {
        setError("Sharing isn't available on this device.");
        return;
      }
      await Sharing.shareAsync(uri, { mimeType: 'image/png', UTI: 'public.png', dialogTitle: 'Share your beast' });
    } catch (e) {
      setError(`Couldn't make the image. ${e instanceof Error ? e.message : ''}`.trim());
    } finally {
      setBusy(null);
    }
  };

  // Shares the images one after the other: the second share sheet opens when the first one closes
  const shareInTurn = async (uris: string[]) => {
    if (!(await Sharing.isAvailableAsync())) throw new Error("Sharing isn't available on this device.");
    for (const uri of uris) {
      await Sharing.shareAsync(uri, { mimeType: 'image/png', UTI: 'public.png', dialogTitle: 'Share your beast' });
    }
  };

  // Both images, straight from the app: the second share sheet opens when the first one closes. No Photos access needed.
  const shareBoth = async () => {
    setError(null);
    setBusy('both');
    try {
      const uris = [await capture(vsRef), await capture(factRef)];
      for (let i = 0; i < uris.length; i++) {
        setStep(i + 1);
        await shareInTurn([uris[i]]);
      }
    } catch (e) {
      setError(`Couldn't share the images. ${e instanceof Error ? e.message : ''}`.trim());
    } finally {
      setStep(0);
      setBusy(null);
    }
  };

  const cardProps = { week: week ?? 4, photoFile: withPhoto ? photoFile : undefined, relation, nickname, secret, w: cardW, h: cardH };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <SafeAreaView style={ui.screen} edges={['top', 'bottom']}>
        <View style={ui.header}>
          <Text style={ui.headerTitle}>Share</Text>
          <Pressable onPress={onClose} hitSlop={8}>
            <Text style={ui.link}>Close</Text>
          </Pressable>
        </View>

        <ScrollView contentContainerStyle={s.body}>
          <ScrollView
            key={secret ? 'secret' : 'both'}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            style={{ width: winW, flexGrow: 0 }}
            onMomentumScrollEnd={(e) => setPage(Math.round(e.nativeEvent.contentOffset.x / winW))}
          >
            {!secret && (
              <View style={[s.pageWrap, { width: winW }]}>
                <StoryCard cardRef={vsRef} mode="vs" {...cardProps} />
              </View>
            )}
            <View style={[s.pageWrap, { width: winW }]}>
              <StoryCard cardRef={factRef} mode="fact" {...cardProps} />
            </View>
          </ScrollView>

          {!secret && (
            <View style={s.pageLabels}>
              {modes.map((m, i) => (
                <Text key={m} style={[s.pageLabel, current === m && s.pageLabelOn]}>
                  {i + 1}. {m === 'vs' ? 'vs Baby 👶' : 'Gross fact 🤢'}
                </Text>
              ))}
            </View>
          )}

          <View style={s.controls}>
            {photoFile && <Toggle label="Include bump photo" value={withPhoto} onChange={setWithPhoto} />}
            <Toggle
              label="Secret mode (just beast, no week)"
              value={secret}
              onChange={(v) => {
                setSecret(v);
                setPage(0);
              }}
            />
            {error && <Text style={{ color: C.danger, textAlign: 'center' }}>{error}</Text>}
            {step > 0 && <Text style={s.savedText}>Sharing image {step} of 2</Text>}
            {secret ? (
              <Pressable style={ui.primaryBtn} onPress={shareOne} disabled={!!busy}>
                {busy ? <ActivityIndicator color={C.accentText} /> : <Text style={ui.primaryBtnText}>Share image</Text>}
              </Pressable>
            ) : (
              <>
                <Pressable style={ui.primaryBtn} onPress={shareBoth} disabled={!!busy}>
                  {busy === 'both' ? (
                    <ActivityIndicator color={C.accentText} />
                  ) : (
                    <Text style={ui.primaryBtnText}>Share both</Text>
                  )}
                </Pressable>
                <Pressable style={ui.secondaryBtn} onPress={shareOne} disabled={!!busy}>
                  {busy === 'one' ? (
                    <ActivityIndicator color={C.text} />
                  ) : (
                    <Text style={ui.secondaryBtnText}>Share just this one</Text>
                  )}
                </Pressable>
              </>
            )}
          </View>
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
}

function StoryCard({
  cardRef,
  mode,
  week,
  photoFile,
  relation,
  nickname,
  secret,
  w,
  h,
}: {
  cardRef: React.RefObject<View | null>;
  mode: Extra;
  week: number;
  photoFile?: string;
  relation: Relation;
  nickname: string;
  secret: boolean;
  w: number;
  h: number;
}) {
  const [stageH, setStageH] = useState(0);
  const info = infoForWeek(week);
  const k = w / 360; // font scale
  const pct = Math.min(100, Math.round((week / LAST_WEEK) * 100));
  const weeksLeft = Math.max(0, LAST_WEEK - week);
  const m = info.animal.match(/^(A|An) (.*)$/);
  const article = m ? m[1].toLowerCase() : '';
  const name = m ? m[2] : info.animal;

  return (
    <View ref={cardRef} collapsable={false} style={[s.card, { width: w, height: h, padding: 24 * k }]}>
      <Text style={[s.week, { fontSize: 15 * k }]}>{secret ? 'THIS WEEK' : `WEEK ${week}`}</Text>

      {photoFile ? (
        <View style={[s.photoWrap, { borderRadius: 20 * k, marginTop: 14 * k }]}>
          <Image source={{ uri: photoUri(photoFile) }} style={s.photo} />
          <View style={[s.badge, { height: 76 * k, borderRadius: 38 * k, right: 12 * k, bottom: 12 * k, paddingHorizontal: 14 * k }]}>
            <Text style={{ fontSize: (mode === 'vs' ? 34 : 44) * k }}>{mode === 'vs' ? `${info.emoji}=👶` : info.emoji}</Text>
          </View>
        </View>
      ) : (
        <View style={[s.stage, { borderRadius: 20 * k, marginTop: 14 * k }]} onLayout={(e) => setStageH(e.nativeEvent.layout.height)}>
          {stageH > 0 && <Habitat week={week} height={stageH} />}
          {mode === 'vs' ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 * k }}>
              <Text style={{ fontSize: 84 * k }}>{info.emoji}</Text>
              <View style={[s.eq, { borderRadius: 20 * k, paddingHorizontal: 8 * k, paddingVertical: 4 * k }]}>
                <Text style={[s.eqSign, { fontSize: 28 * k, lineHeight: 30 * k }]}>=</Text>
              </View>
              <BabyFigure size={96 * k} />
            </View>
          ) : (
            <Text style={{ fontSize: 120 * k }}>{info.emoji}</Text>
          )}
        </View>
      )}

      <View style={{ marginTop: 14 * k }}>
        <Text style={[s.lead, { fontSize: 16 * k }]}>
          {secret ? wordsFor(relation).shareBeast : wordsFor(relation, nickname).shareBaby} is the size of {article}
        </Text>
        <Text style={[s.name, { fontSize: 30 * k, lineHeight: 34 * k }]}>{name.replace(/^./, (c) => c.toUpperCase())}</Text>
        {!secret && (
          <Text style={[s.stats, { fontSize: 14 * k, marginTop: 4 * k }]}>
            {formatLength(info.lengthCm)} · {formatWeight(info.weightG)}
          </Text>
        )}

        {!secret && (
          <View style={{ marginTop: 12 * k }}>
            <View style={{ height: 22 * k, justifyContent: 'center' }}>
              <View style={[s.rail, { height: 7 * k, borderRadius: 4 * k, left: 10 * k, right: 10 * k }]} />
              <View style={[s.railFill, { height: 7 * k, borderRadius: 4 * k, left: 10 * k, width: `${pct * 0.9}%` }]} />
              <Text style={{ position: 'absolute', right: -2 * k, fontSize: 14 * k }}>🏁</Text>
              <Text style={{ position: 'absolute', left: `${pct * 0.9}%`, fontSize: 18 * k }}>{info.emoji}</Text>
            </View>
            <Text style={[s.stats, { fontSize: 13 * k, marginTop: 2 * k }]}>
              <Text style={{ color: C.accent }}>{pct}% cooked</Text>
              {weeksLeft > 0 ? ` · ${weeksLeft} ${weeksLeft === 1 ? 'week' : 'weeks'} to go` : ' · Due now!'}
            </Text>
          </View>
        )}

        {mode === 'fact' && (
          <Text style={[s.fact, { fontSize: 14 * k, lineHeight: 20 * k, marginTop: 12 * k }]}>🤢 {info.fact}</Text>
        )}
        {mode === 'vs' && (
          <View style={{ marginTop: 12 * k, gap: 6 * k }}>
            <View style={{ flexDirection: 'row', paddingHorizontal: 8 * k }}>
              <Text style={[s.vsHead, { fontSize: 11 * k }]}>{info.emoji} Beast</Text>
              <Text style={[s.vsHead, { fontSize: 11 * k }]}>👶 Baby</Text>
            </View>
            {info.vs.slice(0, photoFile ? 1 : 2).map(([topic, a, b]) => (
              <View key={topic} style={[s.vsRow, { borderRadius: 12 * k, padding: 8 * k }]}>
                <Text style={[s.vsTopic, { fontSize: 10 * k }]}>{topic.toUpperCase()}</Text>
                <View style={{ flexDirection: 'row', gap: 8 * k, marginTop: 2 * k }}>
                  <Text style={[s.vsText, { fontSize: 12 * k, lineHeight: 16 * k }]}>{a}</Text>
                  <Text style={[s.vsText, { fontSize: 12 * k, lineHeight: 16 * k }]}>{b}</Text>
                </View>
              </View>
            ))}
          </View>
        )}
      </View>

      <Text style={[s.brand, { fontSize: 13 * k, marginTop: 18 * k }]}>🪳 babybeast</Text>
    </View>
  );
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <View style={s.toggle}>
      <Text style={s.toggleText}>{label}</Text>
      <Switch value={value} onValueChange={onChange} trackColor={{ true: C.accent, false: C.line }} accessibilityLabel={label} />
    </View>
  );
}

const s = StyleSheet.create({
  body: { alignItems: 'center', gap: 14, paddingBottom: 32 },
  pageWrap: { alignItems: 'center' },
  pageLabels: { flexDirection: 'row', gap: 16 },
  pageLabel: { color: C.muted, fontSize: 14, fontWeight: '700' },
  pageLabelOn: { color: C.accent },
  savedText: { color: C.accent, textAlign: 'center', fontWeight: '700', lineHeight: 21 },
  card: { backgroundColor: C.bg, borderRadius: 24, borderWidth: 1, borderColor: C.line, overflow: 'hidden' },
  week: { color: C.accent, fontWeight: '800', letterSpacing: 2 },
  photoWrap: { flex: 1, overflow: 'hidden', backgroundColor: C.card },
  photo: { width: '100%', height: '100%' },
  badge: { position: 'absolute', minWidth: 76, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' },
  lead: { color: C.muted, fontWeight: '600' },
  name: { color: C.text, fontWeight: '800' },
  stats: { color: C.muted, fontWeight: '600' },
  fact: { color: C.text },
  brand: { color: C.muted, fontWeight: '700' },
  controls: { alignSelf: 'stretch', gap: 10, paddingHorizontal: 24 },
  stage: { flex: 1, overflow: 'hidden', alignItems: 'center', justifyContent: 'center', backgroundColor: C.card },
  rail: { position: 'absolute', backgroundColor: C.line },
  railFill: { position: 'absolute', backgroundColor: C.accent },
  vsRow: { backgroundColor: C.card },
  vsHead: { flex: 1, color: C.muted, fontWeight: '800' },
  eq: { backgroundColor: 'rgba(20,32,26,0.75)' },
  eqSign: { color: C.accent, fontWeight: '900' },
  vsTopic: { color: C.accent, fontWeight: '800', letterSpacing: 1 },
  vsText: { flex: 1, color: C.text },
  toggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: C.card,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  toggleText: { color: C.text, fontSize: 15, fontWeight: '600', flex: 1, marginRight: 12 },
});
